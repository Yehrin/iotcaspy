[toc]

# iotcaspy

IoTCAS的Python开源库。



# 使用方法

下载代码：

```shell
$ cd 指定的目录/
$ git clone https://github.com/Yehrin/iotcaspy.git
```

在自己的工程里导入模块：

```python
import sys
sys.path.append('指定的目录/')
from IoTCASUtils import FileUtils
from IoTCASUtils import PandasUtils
from IoTCASUtils import UrlUtils
```











